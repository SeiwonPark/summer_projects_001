class Currency {

    private String nation;
    private int amount;

    Currency(int amount, String nation){
        this.amount = amount;
        this.nation = nation;
    }

}
