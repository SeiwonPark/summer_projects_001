public interface Exchange {
    void exchange(int amount, int objAmount);
}
